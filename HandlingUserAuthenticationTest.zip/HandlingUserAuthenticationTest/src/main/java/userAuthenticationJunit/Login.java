package userAuthenticationJunit;

import java.util.Scanner;

public abstract class Login
{
	
	public static String storeid = "abc@xyz.com";
	public static String storepass = "abc@123";
	
	public static Scanner sc = new Scanner(System.in);
	public static String pass;
	public static String id;
	
	public static void inputid() {
		System.out.println("Enter ID: ");
		id=sc.next();	
	}
	
	public static void inputpass() {
		System.out.println("Enter Password: ");
		pass=sc.next();
	}
	
	public static boolean authenticate() {
		if(id.equals(storeid) && pass.equals(storepass))
			return true;
		else return false;
	}	
}
