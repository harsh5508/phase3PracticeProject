package userAuthenticationJunit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

@DisplayName("Junit 5 standard Test Class Example")
class Authenticate {
	
	@BeforeAll
	@DisplayName("First Testcase.")
	static void authenticationTestCase() {
		Login.inputid();
		Login.inputpass();
	    
	    assertNotNull(Login.id);
	    assertNotNull(Login.pass);		
	}

	@Test
	@DisplayName("Testcase for Authentication of User")
	void userAuthenticate() {
		assertNotNull(Login.id);
		assertEquals(Login.storeid,Login.id);
	}
	
	@Test
	@DisplayName("Testcase for Authentication of Password")
	void passwordAuthenticate() {
		assertNotNull(Login.pass);
		assertEquals(Login.storepass, Login.pass);
	}
	
	@AfterAll
	@DisplayName("Last Testcase.")
	static void last() {
		
		if (Login.authenticate())
			System.out.println("Authentication Successfull...");
		else System.out.println("Authentication Failed...");
		
		Login.id = null;
		Login.pass = null;
		
		assertNull(Login.id);
		assertNull(Login.pass);
	}

}
